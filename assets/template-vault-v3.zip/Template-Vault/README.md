# Template Vault — Construction Workflow Templates

**FieldBridge HQ** | 40 professional templates for construction project management

---

## 📂 Folder Structure

### 01 — Logs & Registers (9 templates)
Core tracking tools you use every day on any project.

| File | What It Does |
|------|-------------|
| `01-rfi-log-tracker.xlsx` | Track all RFIs — status, dates, response times |
| `02-submittal-register.xlsx` | Manage submittal reviews — approved/revise/reject |
| `03-change-order-log.xlsx` | Log all change orders with dollar tracking |
| `07-spec-checklist.xlsx` | Track spec compliance across divisions |
| `17-risk-register.xlsx` | Identify & mitigate project risks |
| `22-correspondence-log.xlsx` | Log all project correspondence |
| `28-issue-log.xlsx` | Track issues from open to resolution |
| `29-decision-log.xlsx` | Log key decisions with rationale |
| `35-drawing-register.xlsx` | Track drawing revisions and approvals |

---

### 02 — Reports (7 templates)
Status reports and daily documentation.

| File | What It Does |
|------|-------------|
| `04-weekly-status-report.docx` | Weekly project status — safety, schedule, RFIs, issues |
| `08-daily-site-report.docx` | Daily site documentation — workforce, equipment, delays |
| `11-monthly-progress-report.docx` | Comprehensive monthly project status |
| `31-material-delivery-log.xlsx` | Track material deliveries — quantities, condition |
| `32-daily-manpower-log.xlsx` | Daily headcount by trade |
| `33-photo-log.xlsx` | Index and catalog site photos |
| `40-progress-photo-log.xlsx` | Organize progress photos by milestone |

---

### 03 — Meetings (3 templates)
Keep meetings productive and documented.

| File | What It Does |
|------|-------------|
| `05-meeting-minutes.docx` | Full meeting minutes — attendees, agenda, actions |
| `09-meeting-agenda.docx` | Pre-meeting agenda with time allocations |
| `10-pre-con-meeting-agenda.docx` | Pre-construction meeting — 5 sections, action items |

---

### 04 — Financial (6 templates)
Budget, payments, and compliance tracking.

| File | What It Does |
|------|-------------|
| `24-pay-application-tracker.xlsx` | Track all pay applications and payments |
| `26-project-budget.xlsx` | Budget vs actual vs forecast by cost code |
| `34-warranty-tracking.xlsx` | Manage equipment/system warranty periods |
| `36-lien-waiver-tracker.xlsx` | Track lien waivers from all tiers |
| `37-insurance-cert-tracker.xlsx` | Monitor insurance certificate expiry dates |
| `38-contract-status.xlsx` | Track contract values, COs, and completion |

---

### 05 — Quality & Safety (7 templates)
Inspection, safety, and closeout checklists.

| File | What It Does |
|------|-------------|
| `12-punch-list.docx` | Punch walk — 20 items, trade, dates, status |
| `13-safety-meeting-log.docx` | Daily/Weekly safety meeting with sign-in |
| `14-site-inspection-checklist.docx` | 5-category site inspection with deficiencies |
| `15-quality-control-checklist.docx` | Materials, installation, testing verification |
| `16-safety-incident-report.docx` | Full incident investigation — root cause + corrective actions |
| `19-project-closeout-checklist.docx` | 20+ closeout items by category |
| `25-substantial-completion.docx` | Certificate of Substantial Performance |

---

### 06 — Change Management (3 templates)
Formal documentation for project changes.

| File | What It Does |
|------|-------------|
| `20-rfi-form.docx` | Formal RFI — drawing refs, attachments, response field |
| `21-transmittal-form.docx` | Document transmittal — action requested, distribution |
| `23-change-order-request.docx` | COR — scope, schedule impact, cost breakdown, approvals |

---

### 07 — Planning (3 templates)
Strategic planning and continuous improvement.

| File | What It Does |
|------|-------------|
| `06-priority-matrix.docx` | Eisenhower matrix — Q1–Q4, task register, decision guide |
| `18-lessons-learned.docx` | Post-phase review — wins, improvements, takeaways |
| `27-milestone-tracker.xlsx` | Track all project milestones with variance |

---

### 08 — Resources (2 templates)
People and equipment management.

| File | What It Does |
|------|-------------|
| `30-subcontractor-directory.xlsx` | Subcontractor contacts, insurance, status |
| `39-equipment-log.xlsx` | Equipment tracking — location, rental cost, status |

---

## Getting Started

1. **Open the folder** that matches what you need to manage
2. **Open the template** — Excel files have dropdowns, filters, and conditional formatting. Word files have fillable fields and tables
3. **Fill in your project data** — save as a new file (keep the original template clean)
4. **Reuse on every project** — templates are designed to be used repeatedly

*Excel templates:* Auto-filtered, frozen header row, dropdown menus on status columns
*Word templates:* Navy header band, fillable fields (_____), checkable boxes (☐), signature blocks

---

**FieldBridge HQ** — Construction Workflow Systems
fieldbridgehq.com
