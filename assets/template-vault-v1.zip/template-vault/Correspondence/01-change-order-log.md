# CHANGE ORDER TRACKING LOG

## Project: _______________________

| # | CO# | Description | Sub | Date Submitted | Amount | Status | Date Approved | Days to Close |
|---|-----|-------------|:---:|:--------------:|:------:|:------:|:-------------:|:-------------:|
| 1 |     |             |     |                |        |        |              |               |
| 2 |     |             |     |                |        |        |              |               |
| 3 |     |             |     |                |        |        |              |               |

## STATUS KEY
- 🔴 PENDING REVIEW
- 🟡 UNDER NEGOTIATION
- 🟢 APPROVED
- ❌ REJECTED
- 📋 INVOICED

## SUMMARY
- Total Pending COs: _____ ($__________)
- Total Approved COs: _____ ($__________)
- Avg Approval Time: _____ Days
- Total Budget Impact: $__________

## CO TRACKING BY CATEGORY
| Category | Count | Total Value |
|----------|:-----:|:-----------:|
| Design Change |       |             |
| Field Condition |       |             |
| Owner Change |       |             |
| Escalation/Price |       |             |
| Other |       |             |
