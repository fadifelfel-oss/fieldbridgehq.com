# SUBMITTAL REGISTER

## Project: _______________________

| # | Spec Section | Description | Subcontractor | Date Submitted | Rev | Status | Date Approved | Reviewer | Notes |
|---|-------------|-------------|--------------|--------------|:---:|:------:|:-------------:|:--------:|-------|
| 1 |             |             |              |              | 1.0 |        |              |          |       |
| 2 |             |             |              |              | 1.0 |        |              |          |       |
| 3 |             |             |              |              | 1.0 |        |              |          |       |

## STATUS KEY
- ✅ APPROVED
- ✅ APPROVED AS NOTED
- 🔄 REVISIONS REQUIRED
- ❌ REJECTED
- ⏳ IN REVIEW

## METRICS
- Total Submittals Submitted: _____
- Avg Days to Approval: _____
- Resubmission Rate: _____%
- Longest Outstanding: _____ Days (Item #___)

## HIGH-RESUBMISSION VENDORS
| Vendor | Items Submitted | Rounds Avg | Status |
|--------|:--------------:|:----------:|:------:|
|        |                |            |        |
|        |                |            |        |
|        |                |            |        |
