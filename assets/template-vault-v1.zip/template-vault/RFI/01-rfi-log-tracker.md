# RFI LOG TRACKER

## Project: _______________________

| # | RFI # | Date Opened | Source | Subcontractor | Spec Section | Description | Urgency | Assigned To | Date Sent | Due Date | Status | Date Closed | Days Open |
|---|-------|------------|--------|--------------|-------------|-------------|---------|------------|----------|---------|--------|------------|----------|
| 1 |       |            |        |              |             |             |         |            |          |         |        |            |          |
| 2 |       |            |        |              |             |             |         |            |          |         |        |            |          |
| 3 |       |            |        |              |             |             |         |            |          |         |        |            |          |

## URGENCY KEY
- 🛑 URGENT — Safety/structural/stop-work
- ⚠️ HIGH — Schedule-critical
- 🔶 MEDIUM — Needs answer but not blocking
- 🔵 LOW — Informational

## WEEKLY SUMMARY
- Total Open RFIs: _____
- Past 14 Days: _____
- Average Days Open: _____
- Longest Outstanding: _____ (RFI #___)

## BOTTLENECK TRACKING
Top 3 slowest reviewers this month:
1. ___________________
2. ___________________
3. ___________________

Top 3 subs generating most RFIs:
1. ___________________
2. ___________________
3. ___________________
