# RFI PRIORITY CLASSIFICATION MATRIX

Use this matrix to classify every incoming RFI before routing.

## URGENT — Respond Within 24 Hours
- Safety hazard or structural integrity issue
- Requires stop-work or work-around
- Affects critical path activity starting within 48 hours
- Owner-directed change with immediate impact

## HIGH — Respond Within 48-72 Hours
- Affects upcoming activity (next 5 days)
- Multiple trades waiting on answer
- Impacts cost or schedule baseline
- Design change requiring re-approval

## MEDIUM — Respond Within 1 Week
- Design clarification needed
- Non-critical coordination issue
- Substitution request for equivalent material
- Standard spec interpretation

## LOW — Respond Within 2 Weeks
- Record/informational only
- As-built documentation
- Future phase question
- Non-critical clarification

## QUICK CLASSIFICATION
Q1: Does this affect safety or structure?              → URGENT
Q2: Is work stopped or will stop in 2 days?            → URGENT
Q3: Is a trade standing by?                            → HIGH
Q4: Does this affect this week's schedule?             → HIGH
Q5: Is it a clarification or substitution?             → MEDIUM
Q6: Is it for documentation only?                      → LOW
