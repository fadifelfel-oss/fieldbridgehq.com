📁 TEMPLATE VAULT — FieldBridge HQ
====================================
Construction Workflow Templates
Version: 1.0 — May 2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT'S INSIDE
─────────────

📋 RFI/                       — RFI management templates
📋 Submittals/                — Submittal tracking templates  
📋 Reports/                   — Weekly status report templates
📋 Correspondence/            — Change orders & correspondence
📋 Specs/                     — Spec analysis templates
📋 AI-Prompts/                — 47 construction-specific AI prompts

HOW TO USE
──────────

1. Browse to the folder you need
2. Copy the template into your workflow
3. Adjust project-specific details
4. Save and reuse every week

All templates are in Markdown format (.md) — readable in any
text editor, Notepad, VS Code, or your email client.

NEW EVERY MONTH
───────────────

3 new templates added on the 1st of each month.
Check your email or log back in to download the update.

NEED HELP?
──────────

Contact: fieldbridgehq.com/services
