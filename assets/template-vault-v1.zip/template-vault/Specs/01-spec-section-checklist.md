# SPEC SECTION CHECKLIST

## Project: _______________________
## CSI Division: ___________________

### GENERAL INFORMATION
- Section Number: _______________
- Section Title: _______________
- Related Sections: _______________

### MATERIAL REQUIREMENTS
| Requirement | Spec Reference | Status | Notes |
|-------------|:--------------:|:------:|-------|
|             |                |        |       |
|             |                |        |       |
|             |                |        |       |

### INSTALLATION REQUIREMENTS
| Requirement | Spec Reference | Status | Notes |
|-------------|:--------------:|:------:|-------|
|             |                |        |       |
|             |                |        |       |
|             |                |        |       |

### SUBMITTAL REQUIREMENTS
| Required Submittal | Spec Reference | Status | Notes |
|-------------------|:--------------:|:------:|-------|
|                   |                |        |       |
|                   |                |        |       |
|                   |                |        |       |

### TESTING / COMMISSIONING
| Test | Standard | Frequency | Status |
|------|----------|:---------:|:------:|
|      |          |           |        |
|      |          |           |        |
|      |          |           |        |

### KEY DATES
- Submittal Due: _______________
- Material Delivery: _______________
- Installation Start: _______________
- Inspection/Testing: _______________

### NOTES
___________________________________________________
___________________________________________________
