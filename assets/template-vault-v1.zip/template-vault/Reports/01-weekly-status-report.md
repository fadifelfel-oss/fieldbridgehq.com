# WEEKLY STATUS REPORT

## Project: _______________________
## Report Date: ___________________
## Prepared By: ___________________
## Reporting Period: ___ to ___

### 1. WORK COMPLETED THIS PERIOD
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________

### 2. SCHEDULE STATUS
- Planned Progress: _____%
- Actual Progress: _____%
- Variance: _____ days (behind/ahead)

### 3. RFI STATUS
- Opened This Period: _____
- Closed This Period: _____
- Total Open RFIs: _____
- Key Items: ____________________________________

### 4. SUBMITTAL STATUS
- Submitted This Period: _____
- Approved: _____
- Revisions Required: _____
- Key Items: ____________________________________

### 5. CHANGE ORDERS
- Pending COs: _____ ($___________)
- Approved COs: _____ ($___________)
- Total CO Budget Impact: $___________

### 6. ISSUES & RISKS
| # | Issue | Impact | Action Required | Owner | By When |
|---|-------|--------|----------------|-------|---------|
| 1 |       |        |                |       |         |
| 2 |       |        |                |       |         |
| 3 |       |        |                |       |         |

### 7. NEXT PERIOD LOOKAHEAD
- _______________________________________________
- _______________________________________________
- _______________________________________________

### 8. PHOTOS / ATTACHMENTS
- [ ] Site photos attached
- [ ] RFI log attached
- [ ] Submittal register attached
- [ ] Updated schedule attached

---

**Reviewed By:** ___________________
**Date:** ___________________
