# Construction-Specific AI Prompts — 47 Battle-Tested Templates

> A curated collection of production-ready prompts for construction project managers, engineers, and superintendents. Designed for use with Claude, GPT-4, Gemini, or any LLM platform. Each prompt is copy-paste ready — just fill in the `{variable}` placeholders.

---

## 1. RFI Management (8 Prompts)

---

### Prompt 1.1 — Classify RFI Urgency

**Analyze the following RFI and classify its urgency as Low, Medium, High, or Critical based on its impact to schedule, cost, and follow-on work:**

```text
Project: {project_name}
RFI #{rfi_number}
Date Submitted: {date}
Originating Trade: {trade}
Subject: {rfi_subject}
Description: {rfi_description}
Reference Spec Section: {spec_section}
Affected Work Areas: {affected_areas}
Submission Due Date: {due_date}
Current Schedule Status: {schedule_status}
```

**Expected output format:** A single urgency rating (Low / Medium / High / Critical) with a 2–3 sentence justification citing specific items from the RFI text.

**Pro tip:** Paste your project's defined urgency matrix alongside the RFI text for more consistent classification.

---

### Prompt 1.2 — Map RFI to Correct Reviewer

**Based on the RFI content below, identify the correct reviewer(s) from the project team. Consider discipline, speciality, subconsultant scope, and any sub-tier review requirements:**

```text
RFI #{rfi_number}
Subject: {rfi_subject}
Spec Section: {spec_section}
Discipline: {discipline}
Question Details: {rfi_description}
Attachments: {attachments_list}
```

**Available Reviewers:**
```text
{list_of_reviewers_with_disciplines}
```

**Expected output format:** Primary reviewer name + discipline, secondary reviewer (if needed), and a one-sentence routing note explaining the assignment.

**Pro tip:** Keep your reviewer roster updated with current contact info and subconsultant assignments — stale rosters cause misrouted RFIs.

---

### Prompt 1.3 — Draft RFI Response

**Draft a clear, technically sound response to the following RFI. Base your answer on the referenced spec section and any attached information. If the spec is ambiguous, note the ambiguity and propose a clarification:**

```text
RFI #{rfi_number}
From: {requesting_party}
Date: {date}
Spec Section Reference: {spec_section}
Question: {rfi_question}
Supporting Info: {supporting_documents_or_drawings}
```

**Expected output format:** A formal RFI response with: (1) clear answer, (2) basis statement citing spec/drawing reference, (3) any impact to cost or schedule noted, (4) suggested response deadline.

**Pro tip:** Always include the exact spec paragraph number in your basis statement — it saves the PM from having to look it up later.

---

### Prompt 1.4 — Check RFI Completeness

**Review the following RFI submission for completeness against standard best practices. Flag any missing elements that could cause delays in review or require a return without action:**

```text
RFI #{rfi_number}
Submitted By: {submitting_company}
Trade: {trade}
Spec Section Referenced: {spec_section}
Drawing Reference: {drawing_reference}
Question Text: {rfi_text}
Attachments: {attachments}
Markups/Redlines Included: {yes_or_no}
```

**Completeness Checklist:**
- [ ] Clear, unambiguous question stated
- [ ] Spec section and paragraph cited
- [ ] Drawing sheet and detail number cited
- [ ] Attachments present and legible
- [ ] Markups/redlines included where relevant
- [ ] Product data or submittal cross-referenced
- [ ] Schedule impact noted if applicable

**Expected output format:** A checklist table showing which items pass/fail, followed by a summary list of missing elements and a go/no-go recommendation for acceptance.

**Pro tip:** Create a standardized RFI intake template for your subs to use — it eliminates 90% of completeness issues before they reach you.

---

### Prompt 1.5 — Cross-Reference RFI Against Specs and Drawings

**Cross-reference the RFI question below against the provided spec section excerpt and drawing notes. Identify any discrepancies, conflicts, or missing information between the RFI and the reference documents:**

```text
RFI #{rfi_number}
Question: {rfi_question}
Spec Section Excerpt: {spec_excerpt}
Drawing Sheet/Detail: {drawing_reference}
Drawing Note Text: {drawing_notes}
```

**Expected output format:** A conflict matrix listing each RFI claim vs. spec vs. drawing, with a verdict (Consistent / Conflicts / Not Addressed) and recommended resolution for each conflict.

**Pro tip:** Run this cross-reference check *before* assigning the RFI to a reviewer — it often reveals that the question is based on a faulty premise.

---

### Prompt 1.6 — Summarize RFI Log

**Summarize the current RFI log below. Highlight trends, bottlenecks, aging items, and overall health of the RFI process:**

```text
Project: {project_name}
Report Date: {date}
Total RFIs Submitted: {total_count}
Open RFIs: {open_count}
Closed RFIs: {closed_count}
Overdue RFIs: {overdue_count}
Average Response Time: {avg_response_time_days}
RFI Data (table or list):
{rfi_log_data}
```

**Expected output format:** A 4-paragraph executive summary covering: (1) overall volume and closure rate, (2) aging/overdue items requiring escalation, (3) bottleneck reviewers or trades, (4) top 3 recommendations to improve RFI cycle time.

**Pro tip:** Sort your RFI log by age before pasting it in — the model will weight the most critical overdue items more heavily.

---

### Prompt 1.7 — Detect Repeated or Duplicate RFIs

**Analyze the following RFI list and identify any RFIs that are duplicates, near-duplicates, or closely related to previously submitted RFIs. Flag items that ask the same question in different words or reference the same design issue:**

```text
Project: {project_name}
Current RFI: #{current_rfi_number} — {current_rfi_subject} — {current_rfi_description}
Recent RFI History (last 30 days):
{rfi_history_list}
```

**Expected output format:** A list of potential duplicates ranked by similarity (High / Medium / Low), with the matching RFI number, a quote of the overlapping text, and a recommendation (consolidate / close as duplicate / track separately).

**Pro tip:** Set up a monthly batch check of your entire RFI log — some trades will re-submit the same question hoping for a different answer.

---

### Prompt 1.8 — Flag Overdue RFIs and Escalation Recommendations

**Review the RFI log and flag all overdue items. For each overdue RFI, provide an escalation recommendation based on how many days past due it is and its urgency classification:**

```text
Project: {project_name}
Current Date: {current_date}
Overdue Threshold: {threshold_days}
RFI Log:
{rfi_log_data}
```

**Expected output format:** A table with columns: RFI #, Days Overdue, Urgency, Assigned Reviewer, Recommended Escalation Action, and Escalate To (name/role). Append a brief escalation protocol summary.

**Pro tip:** Set your overdue threshold to match your contract's response-time requirement (typically 7 or 10 calendar days) so no contractual deadlines are missed.

---

## 2. Submittal Review (6 Prompts)

---

### Prompt 2.1 — Check Submittal Compliance Against Spec Section

**Review the submittal below for compliance against the referenced spec section. Check that all submittal requirements listed in the spec are addressed, properly formatted, and technically correct:**

```text
Submittal #{submittal_number}
Rev: {revision}
Trade: {trade}
Product/System: {product_name}
Spec Section: {spec_section}
Spec Submittal Requirements: {spec_submittal_requirements_text}
Submittal Package Contents: {submittal_package_description}
```

**Expected output format:** A compliance table listing each spec submittal requirement, whether the submittal addresses it (Pass / Fail / Partial), and specific comments on what is missing or non-compliant.

**Pro tip:** Paste the spec submittal paragraph verbatim rather than paraphrasing it — the model catches more discrepancies with exact text.

---

### Prompt 2.2 — Compare Submittal Revision to Previous

**Compare the current revision of this submittal against the previous revision. Identify all changes, determine whether each change resolves the prior review comments, and flag any new issues introduced:**

```text
Submittal #{submittal_number}
Title: {submittal_title}
Previous Rev ({previous_rev_number}) — Review Status: {previous_status}
Previous Reviewer Comments: {previous_review_comments}
Current Rev ({current_rev_number}) — Changes Made: {list_of_changes_or_submittal_text}
```

**Expected output format:** A revision comparison table listing each previous comment, the current revision's response, whether it's resolved (Yes / Partial / No), and any new concerns introduced by the revision.

**Pro tip:** Ask your submittal coordinator to add change indicators (clouds, callouts, or a change summary sheet) to every resubmission — it saves hours of re-review.

---

### Prompt 2.3 — Flag Missing Attachments in Submittal Package

**Review the submittal package contents and flag any missing attachments, supporting documents, or certifications required by the spec section:**

```text
Submittal #{submittal_number}
Product: {product_name}
Spec Section: {spec_section}
Required Attachments Per Spec: {required_attachments_list}
Actual Attachments Included: {included_attachments_list}
```

**Expected output format:** A gap analysis table listing each required attachment, whether it's included, and a severity rating (Missing / Partial / Present). Include a summary count of missing items.

**Pro tip:** Create a required-attachment checklist per spec section before submittals arrive — it turns this reactive flagging into a proactive gate.

---

### Prompt 2.4 — Verify Product Substitution Request

**Evaluate the following product substitution request against the spec's substitution requirements. Determine whether it meets the criteria for an acceptable substitution based on the provided data:**

```text
Submittal #{submittal_number}
Requested Substitute Product: {substitute_product}
Manufacturer: {manufacturer_model}
Specified Product: {specified_product}
Spec Section: {spec_section}
Substitution Clause Reference: {substitution_clause_text}
Substitution Request Rationale: {rationale}
Supporting Data: {performance_data_certifications}
Price Difference: {price_difference}
Schedule Impact: {schedule_impact}
```

**Expected output format:** A pass/fail determination with supporting reasoning, a checklist of substitution criteria with each evaluated, and a recommendation (Approve / Approve with Conditions / Reject).

**Pro tip:** Always check whether the spec says "or equal" vs. "no substitutions permitted" — the bar is dramatically different and the model needs that exact language to evaluate correctly.

---

### Prompt 2.5 — Summarize Submittal Log Status

**Summarize the current submittal log status, highlighting bottlenecks, aging items, approval rates, and any trends that need management attention:**

```text
Project: {project_name}
Date: {date}
Total Submittals: {total_count}
Approved: {approved_count}
Approved with Comments: {approved_with_comments_count}
Revise and Resubmit: {revise_count}
Rejected: {rejected_count}
Pending Review: {pending_count}
Overdue: {overdue_count}
Average Review Cycle: {avg_review_days}
Submittal Log Data:
{submittal_log_data}
```

**Expected output format:** A 3-paragraph status brief: (1) overall submittal health and approval rate, (2) bottleneck reviewers and slow trades, (3) top 3 actions to improve submittal throughput.

**Pro tip:** Track submittal cycle time per reviewer — the data often reveals which disciplines are overloaded or slow to respond.

---

### Prompt 2.6 — Generate Submittal Review Comments

**Generate clear, actionable review comments for the submittal below. Each comment must reference the specific requirement from the spec or drawings and state exactly what change is needed:**

```text
Submittal #{submittal_number}
Rev: {revision}
Product/System: {product_name}
Reviewing Discipline: {discipline}
Non-Compliance Issues Found: {list_of_issues}
Spec/Drawing References: {applicable_references}
```

**Expected output format:** Numbered review comments in this format for each issue:
- **Comment X:** [Issue description]
- **Requirement:** [Spec/drawing reference]
- **Action Required:** [Exactly what the submittal preparer must change]
- **Severity:** (Critical / Major / Minor)

**Pro tip:** Use the phrase "Revise to show..." or "Provide..." to start each Action Required line — it forces clear, directive language that subs can execute without interpretation.

---

## 3. Spec Analysis (5 Prompts)

---

### Prompt 3.1 — Extract Requirements from Spec Section

**Extract all requirements from the following spec section and organize them by category. Identify submittal requirements, testing requirements, installation requirements, material requirements, and coordination requirements:**

```text
Project: {project_name}
Spec Section: {section_number_and_title}
Spec Text:
{spec_section_text}
```

**Expected output format:** A categorized requirements table with columns: Category, Requirement ID, Requirement Text (from spec paragraph), Compliance Verification Method, and Responsible Party.

**Pro tip:** For large spec sections (30+ pages), feed the spec text in chunks and ask for incremental extraction — the model maintains better accuracy on smaller batches.

---

### Prompt 3.2 — Compare Two Spec Versions

**Compare the following two versions of the same spec section. Identify all changes between versions, classify each change by type and impact, and flag items that could affect cost, schedule, or procurement:**

```text
Spec Section: {section_number_and_title}
Project: {project_name}
Version 1 (Original/Previous):
{spec_version_1_text}
Version 2 (Revised/Current):
{spec_version_2_text}
```

**Expected output format:** A change log table with: Change #, Location (paragraph), Nature of Change (Added / Deleted / Modified), Old Text (excerpt), New Text (excerpt), Impact (Cost / Schedule / Procurement / None), and Severity (High / Medium / Low).

**Pro tip:** Always check version dates — late spec revisions issued after procurement has started are a major source of change orders.

---

### Prompt 3.3 — Identify Conflicting Requirements

**Analyze the following spec sections for conflicting requirements. Flag any instances where two sections require incompatible products, contradicting installation methods, or inconsistent quality/performance standards:**

```text
Project: {project_name}
Section A: {section_a_number} — {section_a_title}
Section A Excerpt: {section_a_text}
Section B: {section_b_number} — {section_b_title}
Section B Excerpt: {section_b_text}
```

**Expected output format:** A conflict register with Conflict #, Sections Involved, Description of Conflict, Reference Paragraphs, Potential Impact, and Recommended Resolution.

**Pro tip:** Cross-reference Division 1 (General Requirements) against every trade-specific section — that's where the most common general-vs-specific conflicts hide.

---

### Prompt 3.4 — Summarize Division-Level Requirements

**Provide a high-level summary of all requirements across the following spec division. Cover submittals, testing, commissioning, warranty, and coordination requirements that apply to multiple sections within this division:**

```text
Project: {project_name}
Spec Division: {division_number} — {division_title}
Sections in Division: {section_list}
Division-Level General Requirements: {division_level_text}
```

**Expected output format:** A division summary with: (1) overview of division scope, (2) shared submittal requirements, (3) shared testing/commissioning requirements, (4) warranty and O&M requirements, (5) cross-section coordination requirements, (6) key deadlines and milestones referenced in the division.

**Pro tip:** Use this prompt at project kickoff to build your master deliverables matrix — it catches specification-based deadlines that often get missed.

---

### Prompt 3.5 — Generate Inspection Checklist from Spec Section

**Create a detailed inspection checklist from the following spec section. The checklist should cover all items that need verification during construction, including materials, installation, testing, and final acceptance:**

```text
Project: {project_name}
Spec Section: {section_number_and_title}
Spec Text:
{spec_section_text}
```

**Expected output format:** A checklist organized by inspection phase (Pre-Installation / During Installation / Post-Installation / Testing / Final Acceptance) with each line item referencing the specific spec paragraph. Include a Pass/Fail/N/A column and a remarks column.

**Pro tip:** Map each checklist item to a specific construction phase so field inspectors know exactly which items to check at which point in the work.

---

## 4. Schedule & Planning (6 Prompts)

---

### Prompt 4.1 — Analyze Critical Path Delays

**Analyze the following schedule data and identify activities causing critical path delays. For each delay, quantify the impact and suggest recovery options:**

```text
Project: {project_name}
Schedule Date: {schedule_date}
Data Date: {data_date}
Contract Completion: {contract_completion_date}
Current Forecast Completion: {forecast_completion_date}
Critical Path Activities (with actual/forecast dates):
{critical_path_data}
Delays/Issues Noted: {delay_notes}
```

**Expected output format:** A delay impact table with: Activity ID, Activity Description, Original Duration, Remaining Duration, Delay (Days), Root Cause, Forecast Impact to Completion, and Recovery Recommendations (with duration/cost estimate).

**Pro tip:** Always include float values for each critical path activity — a delayed activity with zero float is a very different problem than one with 20 days of float remaining.

---

### Prompt 4.2 — Generate Lookahead from Schedule

**Generate a {lookahead_window}-day lookahead from the project schedule below. Identify all activities scheduled to start or finish in the lookahead window, flag prerequisite dependencies that may not be met, and highlight mobilized resources that are needed:**

```text
Project: {project_name}
Schedule Date: {current_date}
Lookahead Window: {lookahead_window} days
Schedule Data:
{schedule_data}
```

**Expected output format:** A lookahead report organized by week with: (1) Activities starting, (2) Activities completing, (3) Dependency/predecessor watch list (activities whose predecessors haven't completed), (4) Resource mobilization alerts, (5) Key submittal/approval deadlines in the window.

**Pro tip:** Generate this lookahead every Friday for the following 3 weeks — it gives the Monday foreman's meeting a tactical edge.

---

### Prompt 4.3 — Identify Resource Conflicts

**Analyze the schedule below for resource conflicts. Identify any instances where the same crew, equipment, or key resource is double-booked or where overlapping activities would create logistical conflicts on site:**

```text
Project: {project_name}
Schedule Data:
{schedule_data}
Resource Assignments:
{resource_assignment_data}
Site Constraints: {site_constraints} (e.g., single crane zone, limited laydown area, one access point)
```

**Expected output format:** A conflict register with: Conflict ID, Involved Activities, Resource Type, Conflict Description, Date(s) of Conflict, Risk Level, and Resolution Suggestion (resequence / add resource / adjust shift).

**Pro tip:** Don't forget to check crane and hoist schedules — vertical transportation conflicts are the most common overlooked resource constraint in high-rise construction.

---

### Prompt 4.4 — Check Schedule Logic

**Review the project schedule for logical errors, including missing dependencies, improper sequencing, open-ended activities, dangling logic, and activities with unrealistic predecessor/successor relationships:**

```text
Project: {project_name}
Schedule Data (with predecessors/successors):
{schedule_data}
Schedule Logic Rules: {logic_rules_or_contract_requirements}
```

**Expected output format:** A schedule logic error report listing each issue with: Error Type, Activity ID(s), Description, Impact on Schedule Integrity, and Recommended Fix.

**Pro tip:** Run this check on every schedule update before submitting it to the owner — schedule logic errors are the first thing an experienced scheduler looks for in a delay claim defense.

---

### Prompt 4.5 — Compare As-Planned vs As-Built

**Compare the as-planned schedule against the as-built progress for the period below. Identify variances, quantify schedule drift, and flag activities that are falling behind or ahead of the baseline:**

```text
Project: {project_name}
Baseline Schedule Date: {baseline_date}
Reporting Period: {period_start} to {period_end}
As-Planned Data:
{as_planned_data}
As-Built Progress Data:
{as_built_data}
```

**Expected output format:** A variance report with: Activity ID, Activity Description, Planned Start, Actual Start, Variance (Start), Planned Finish, Forecast Finish, Variance (Finish), % Complete Planned vs Actual, and Action Needed.

**Pro tip:** For forensic analysis, also compare the original baseline (not the last updated schedule) — the most recent update may have already incorporated delay into the plan.

---

### Prompt 4.6 — Flag Unrealistic Durations

**Review the schedule and flag any activity durations that appear unrealistic based on industry benchmarks, crew productivity rates, or typical scopes of work:**

```text
Project: {project_name}
Project Type: {project_type}
Schedule Data:
{schedule_data}
Assume standard crew sizes and typical productivity unless noted otherwise.
```

**Expected output format:** A flagged-duration table with: Activity ID, Activity Description, Stated Duration, Industry Benchmark Range, Variance, Risk Level, and Suggested Duration (if applicable). Include a summary stating how many activities have flagged durations and the total schedule risk.

**Pro tip:** Build a lookup table of your own company's productivity benchmarks by trade and activity type — generic industry data is helpful, but your own historical data is gold.

---

## 5. Estimating & Bidding (6 Prompts)

---

### Prompt 5.1 — Level Bids Against Scope

**Review the following subcontractor or supplier bid and level it against the defined scope of work. Identify inclusions, exclusions, assumptions, and qualifications that differ from the bid package scope:**

```text
Project: {project_name}
Bid Package: {bid_package_name}
Scope of Work Reference: {scope_document_excerpt}
Bidder: {bidder_name}
Bid Amount: ${bid_amount}
Bid Letter / Exclusions / Qualifications:
{bid_text}
```

**Expected output format:** A leveled bid summary table with: Scope Item, In Scope?, Bidder Alignment (Included / Excluded / Qualified / Not Addressed), Unit/Amount, and Adjustment Needed ($). End with a leveled total that accounts for all scope gaps.

**Pro tip:** Require every bidder to use your scope checklist form rather than submitting a free-form letter — it eliminates 80% of leveling guesswork.

---

### Prompt 5.2 — Identify Gaps in Bid

**Analyze the following bid submission and identify gaps where the bidder has not fully covered the scope of work, has made assumptions that shift risk to the GC, or has omitted required components:**

```text
Project: {project_name}
Bid Package: {bid_package_name}
Bidder: {bidder_name}
Bid Amount: ${bid_amount}
Scope Documents: {scope_excerpt}
Bid Submission:
{bid_submission_text}
Bidder Qualifications/Assumptions: {qualifications_list}
```

**Expected output format:** A gap analysis table with: Gap ID, Scope Item, Gap Description, Risk to GC (High / Med / Low), Estimated $ Impact, and Recommendation (Clarify / Add Back / Accept as Risk).

**Pro tip:** Pay special attention to bids that are significantly lower than others — they often have the most scope gaps disguised as "standard exclusions."

---

### Prompt 5.3 — Analyze Quantity Takeoff Variance

**Compare the following quantity takeoff data from two sources (e.g., estimator vs. bidder, or two estimating rounds). Identify variances, calculate percentage differences, and flag items that exceed the materiality threshold:**

```text
Project: {project_name}
Work Package: {work_package}
Source A: {source_a_name}
Source B: {source_b_name}
Materiality Threshold: {threshold_percentage}%
Takeoff Data:
| Item | Unit | Source A Qty | Source B Qty |
{quantity_data}
```

**Expected output format:** A variance table with: Item, Unit, Source A Qty, Source B Qty, Difference, % Variance, Within Threshold (Y/N), and Root Cause Notes. Include a summary of items exceeding the threshold.

**Pro tip:** For concrete, steel, and MEP quantities, a 5% variance is typical — anything above 10% warrants a re-takeoff by both parties.

---

### Prompt 5.4 — Generate Bid Comparison Matrix

**Generate a bid comparison matrix from the following bid tabulation data. Normalize all bids to a common baseline, show line-item pricing, and calculate the spread between the low and high bidder:**

```text
Project: {project_name}
Bid Package: {bid_package_name}
Bid Due Date: {bid_due_date}
Number of Bidders: {bidder_count}
Bid Tabulation Data:
{bid_tabulation_data}
Scope Clarifications Received: {scope_clarifications}
```

**Expected output format:** A matrix with: Bidder Name, Base Bid, Line Items (each scope item with unit prices), Deductive/Additive Alternatives, Leveled Total, and Spread from Low. Include a recommendation box with the preferred bidder and rationale.

**Pro tip:** Always include at least 3 bidders in the matrix — a 2-bid comparison doesn't give you enough market data to validate pricing.

---

### Prompt 5.5 — Check Unit Prices Against Market

**Review the following unit prices against current market benchmarks for {region} and {project_type}. Flag any unit prices that are significantly above or below market range:**

```text
Project: {project_name}
Region: {region}
Project Type: {project_type}
Bidder: {bidder_name}
Unit Price Data:
| Item | Unit | Bid Unit Price | Quantity |
{unit_price_data}
Market Benchmark Data (optional - if not provided, use your knowledge of {region} market rates):
{market_benchmarks}
```

**Expected output format:** A unit price audit table with: Item, Unit, Bid Price, Market Low, Market High, Market Average, Position vs Market, and Flag (Overpriced / Competitive / Underpriced / N/A). Append a risk summary for underpriced items.

**Pro tip:** RSMeans is useful but can lag 6–12 months — supplement with actual recent bid tabs from similar projects in the same market for the most accurate benchmarks.

---

### Prompt 5.6 — Validate Subcontractor Coverage

**Review the bid list and validate that all required trades and scopes are covered by at least one qualified subcontractor bid. Identify any scopes with insufficient coverage, missing bidders, or sole-source situations:**

```text
Project: {project_name}
Bid Package List:
{bid_package_list}
Subcontractor Bid Status:
{bid_status_data}
Required Trades/Scopes: {required_scopes_list}
Qualified Bidders List: {qualified_bidders_list}
```

**Expected output format:** A coverage matrix with: Scope/Bid Package, Number of Bids Received, Qualified Bidders, Coverage Status (Covered / Insufficient / Missing / Sole Source), Risk Level, and Recommended Action.

**Pro tip:** The week before bid day, run this check proactively — discovering a missing trade on bid day morning gives you time to call in a backup quote.

---

## 6. Correspondence (5 Prompts)

---

### Prompt 6.1 — Draft Response to Claim Letter

**Draft a professional, contractually sound response to the following claim letter. Address each allegation, state your position with reference to the contract, and propose next steps:**

```text
Project: {project_name}
Claim Letter Ref: {claim_reference}
Date Received: {date}
From: {claimant}
Claim Amount: ${claim_amount}
Claim Summary: {claim_summary}
Contract Reference (relevant clauses): {contract_clauses}
Supporting Documents (attached): {attachments}
Your Position: {your_position_summary}
```

**Expected output format:** A formal response letter including: (1) reference header, (2) response to each claim allegation with contract clause citations, (3) statement of position (Accept / Reject / Partially Accept), (4) counter-offer if applicable, (5) reservation of rights clause, (6) proposed next steps/meeting date.

**Pro tip:** Never respond to a claim letter without first checking the notice requirements in your contract — missing a notice deadline can waive your defenses entirely.

---

### Prompt 6.2 — Generate Meeting Minutes from Notes

**Generate professional meeting minutes from the following raw notes. Include attendees, discussion items, decisions made, action items with assignments, and next meeting date:**

```text
Project: {project_name}
Meeting Type: {meeting_type} (e.g., OAC, Subcontractor Coordination, Weekly Progress)
Date: {meeting_date}
Time: {meeting_time}
Location: {location_or_virtual_link}
Attendees (from sign-in sheet): {attendees_list}
Raw Notes:
{raw_meeting_notes}
```

**Expected output format:** Structured meeting minutes with:
- Meeting header (project, date, time, location)
- Attendees (present, absent with excuses)
- Agenda items with discussion summary for each
- Decisions recorded
- Action item table: #, Action, Assigned To, Due Date, Status
- Next meeting date and time

**Pro tip:** Send draft minutes within 24 hours of the meeting — the longer you wait, the more attendees will dispute what was agreed.

---

### Prompt 6.3 — Write Change Order Description

**Write a clear, defensible change order description that accurately describes the scope change, the reason for the change, the impact on cost and schedule, and the basis of the price:**

```text
Project: {project_name}
Change Order #{co_number}
Originating Event: {originating_event} (e.g., Owner Directive, Design Change, Changed Condition)
Date of Directive: {directive_date}
Change Description (technical): {change_description}
Reason for Change: {change_reason}
Cost Impact: ${cost_impact}
Schedule Impact: {schedule_impact_days}
Basis of Price: {basis_of_price} (e.g., Lump Sum, T&M Not-to-Exceed, Unit Price)
Supporting Documentation: {attachments}
```

**Expected output format:** A formal change order description with these sections: (1) Description of Change, (2) Reason for Change, (3) Impact on Contract Price, (4) Impact on Contract Time, (5) Basis of Compensation, (6) Attachments referenced.

**Pro tip:** Always include the exact date the owner directed the change in writing — this is your best defense if there's later disagreement about scope creep timing.

---

### Prompt 6.4 — Format RFI for Formal Submission

**Format the following draft RFI into a professional, submission-ready RFI document suitable for formal transmittal. Include all required fields, proper referencing, and clear question phrasing:**

```text
Project: {project_name}
Originating Trade: {trade}
Draft Question/Notes: {draft_rfi_text}
Known Spec/Drawing References: {references}
Priority Level: {priority}
Requested Response Date: {requested_date}
Attachments to Include: {attachments}
```

**Expected output format:** A complete RFI document with: RFI header (project, RFI #, date), To/From fields, Subject line, Spec/Drawing Reference, Detailed Question (rephrased clearly and concisely), Attachments List, Priority, and Requested Response Date.

**Pro tip:** Always phrase the RFI as a specific question ending with a question mark — vague statements like "we need clarification on..." get slower responses than direct "What is the required..." questions.

---

### Prompt 6.5 — Summarize Daily Report

**Summarize the following daily construction report into a concise, highlights-focused brief suitable for distribution to stakeholders who need a quick project update:**

```text
Project: {project_name}
Report Date: {date}
Report Author: {reporter_name}
Weather: {weather_conditions}
Temp: {temperature_range}
Workforce Summary: {total_workers_by_trade}
Equipment on Site: {equipment_list}
Activities Performed: {activities_description}
Deliveries Received: {deliveries_list}
Inspections/Tests Performed: {inspection_summary}
Issues/Incidents: {issues_list}
Safety Notes: {safety_notes}
Photos Taken: {photo_references}
```

**Expected output format:** A 2-paragraph daily brief: (1) key accomplishments and progress made today, notable deliveries, inspections passed, (2) issues encountered, safety observations, and any items needing management attention. Append a 1-line stats bar: Workforce | Weather | Key Equipment.

**Pro tip:** Keep daily reports to one page — if it's longer than that, executives won't read it.

---

## 7. Safety & Quality (5 Prompts)

---

### Prompt 7.1 — Extract Safety Requirements from Specs

**Extract all safety-related requirements from the following spec sections. Include requirements for PPE, fall protection, hot work, confined space, hazardous materials, emergency procedures, and any trade-specific safety protocols mandated by the spec:**

```text
Project: {project_name}
Spec Section(s): {section_numbers}
Spec Text:
{spec_text}
```

**Expected output format:** A safety requirements register organized by: Safety Category, Requirement (with spec paragraph reference), Location/Area Affected, Responsible Trade, and Verification Method (e.g., pre-task plan, JSA, inspection).

**Pro tip:** Cross-reference extracted safety requirements against your project's site-specific safety plan — any spec-mandated safety item not in your SSP is a compliance gap waiting to be found during an OSHA visit.

---

### Prompt 7.2 — Generate Inspection Checklist from Scope

**Generate a detailed quality inspection checklist from the following scope of work or specification section. Include hold points, witness points, and sign-off requirements:**

```text
Project: {project_name}
Work Scope / Spec Section:
{scope_or_spec_text}
Quality Standards Reference: {quality_standards}
Testing Requirements: {testing_requirements}
```

**Expected output format:** A quality inspection checklist organized by installation phase: (1) Pre-Installation (materials, prep, conditions), (2) During Installation (method, tolerances, sequencing), (3) Post-Installation (finish, fit, function), (4) Testing/Commissioning, (5) Close-Out (documentation, O&M, warranties). Include space for date, inspector, and sign-off at each phase.

**Pro tip:** Add a "Photo Required" column to every checklist line item — photographic evidence is your best defense in a quality dispute.

---

### Prompt 7.3 — Analyze Incident Report Patterns

**Analyze the following incident reports for patterns, root causes, and systemic safety issues. Identify any recurring hazards, common contributing factors, and recommend corrective actions:**

```text
Project: {project_name}
Reporting Period: {period_start} to {period_end}
Total Incidents Reported: {incident_count}
Incident Data:
{incident_reports_list}
Near-Miss Data (if available):
{near_miss_data}
```

**Expected output format:** A pattern analysis report with: (1) Incident frequency trend, (2) Incident type distribution (with count), (3) Root cause analysis (by category: equipment / behavior / environment / process), (4) Recurring pattern identification, (5) Top 3 corrective actions ranked by impact, (6) Recommended training or process changes.

**Pro tip:** Include near-miss data alongside actual incidents — a high near-miss count in a specific trade often predicts where the next recordable incident will occur.

---

### Prompt 7.4 — Draft Safety Meeting Topic from Project Phase

**Draft a safety meeting topic tailored to the current project phase. Include relevant hazards, applicable regulations, specific site conditions, and discussion questions for the crew:**

```text
Project: {project_name}
Current Project Phase: {project_phase}
Upcoming Work Activities (next 7 days): {upcoming_activities}
Known Site Hazards: {site_hazards}
Relevant Regulations: {applicable_regulations}
Previous Incidents on This Project (related): {related_incidents}
```

**Expected output format:** A complete safety meeting handout including: (1) Meeting title, (2) 3–5 key hazard points specific to current phase, (3) regulatory/company policy reference, (4) real-world example or project-specific case, (5) 3 discussion questions for the crew, (6) sign-off line for attendee names.

**Pro tip:** Keep safety meetings under 10 minutes and focused on exactly one topic — the 10-minute attention span rule applies to construction safety talks as much as it does to TED talks.

---

### Prompt 7.5 — Flag Quality Risks from Schedule Compression

**Analyze the following schedule compression scenario and flag quality risks that may arise from accelerated construction. Identify specific work activities or trades where rushing could compromise quality:**

```text
Project: {project_name}
Original Duration: {original_duration}
Compressed Duration: {compressed_duration}
Compression Method: {compression_method} (e.g., overtime, overlapping trades, reduced cure times)
Affected Activities: {affected_activities}
Quality Standards/Inspection Requirements:
{quality_standards}
```

**Expected output format:** A quality risk register with: Risk ID, Affected Activity, Quality Risk Description, Likelihood (High / Med / Low), Severity (High / Med / Low), Mitigation Measure, and Responsible Party.

**Pro tip:** The three fastest ways schedule compression kills quality are: (1) reduced concrete cure time, (2) eliminated mockup review, (3) overlapping trades in confined spaces causing rework.

---

## 8. General Productivity (6 Prompts)

---

### Prompt 8.1 — Summarize Project Status for Stakeholder

**Summarize the current project status in an executive-friendly format suitable for a stakeholder who does not follow daily construction details. Focus on key milestones, schedule health, budget status, and top risks:**

```text
Project: {project_name}
Project Phase: {project_phase}
% Complete: {percent_complete}
Contract Value: ${contract_value}
Current Budget: ${current_budget}
Forecast Final Cost: ${forecast_cost}
Original Completion: {original_completion}
Forecast Completion: {forecast_completion}
Top 3 Risks: {top_risks}
Recent Milestones: {recent_milestones}
Upcoming Milestones: {upcoming_milestones}
Safety Record: {safety_record}
Change Order Summary: {change_order_summary}
```

**Expected output format:** A 1-page executive summary with: (1) Project snapshot bar (cost, schedule, safety), (2) Narrative status in 3 paragraphs (Progress / Budget / Schedule), (3) Top 3 risks and mitigation actions, (4) 30-day lookahead highlights.

**Pro tip:** For executive audiences, lead with the "traffic light" — green/yellow/red ratings for cost, schedule, and safety — before diving into text.

---

### Prompt 8.2 — Generate Weekly Report Data

**Generate comprehensive weekly report content from the following raw project data. Include progress on work activities, issues, safety metrics, quality highlights, and forecast for the coming week:**

```text
Project: {project_name}
Reporting Week: {week_start} to {week_end}
Work Completed: {work_completed_this_week}
Work Planned Next Week: {work_planned_next_week}
Issues Logged: {issues_this_week}
RFIs Submitted/Resolved: {rfi_activity}
Submittals Status: {submittal_activity}
Safety Highlights: {safety_highlights}
Quality Highlights: {quality_highlights}
Weather Impact: {weather_impact}
Change Orders Pending: {pending_co_count_and_value}
Photos from Week: {photo_list}
```

**Expected output format:** A structured weekly report with sections: (1) Executive Summary, (2) Progress by Area/Trade, (3) RFI & Submittal Activity, (4) Issues & Resolutions, (5) Safety & Quality, (6) Lookahead (Next Week), (7) Photo Summary with captions.

**Pro tip:** Keep the executive summary to 5 bullet points max — if everything is a priority, nothing is a priority.

---

### Prompt 8.3 — Draft Email to Subcontractor

**Draft a professional email to {subcontractor_name} regarding {email_topic}. The tone should be {tone} (e.g., firm but professional, collaborative, escalation notice). Include clear action items and deadlines:**

```text
To: {subcontractor_name}
Project: {project_name}
Subject: {email_subject}
Context/Background: {context}
Specific Issue: {issue_description}
Desired Outcome: {desired_outcome}
Deadline: {deadline}
Previous Communications on This Topic: {previous_comm_summary}
Tone Guidance: {tone}
```

**Expected output format:** A ready-to-send email with: (1) Clear subject line with project reference, (2) Professional greeting, (3) Background context (1–2 sentences), (4) Issue statement with specific examples/dates, (5) Action requested with deadline, (6) Consequence if not completed (if escalation), (7) Professional closing.

**Pro tip:** Never send a subcontractor email that doesn't include a specific deadline in the first paragraph — vague emails get vague responses.

---

### Prompt 8.4 — Analyze Subcontractor Performance from RFI History

**Analyze the following subcontractor's performance based on their RFI history, submittal track record, and any quality/safety issues. Provide a performance assessment and recommendations for managing this subcontractor going forward:**

```text
Subcontractor: {subcontractor_name}
Trade: {trade}
Contract Value: ${contract_value}
% Complete: {percent_complete}
RFI History (submitted by this sub): {their_rfi_history}
RFI Quality Score (if tracked): {rfi_quality_score}%
Submittal History: {submittal_history}
Submittal R&R Rate: {resubmit_rate}%
Quality Issues: {quality_issues_list}
Safety Record: {safety_record}
Punch List Items Open: {punch_list_count}
Schedule Compliance (on-time %): {schedule_compliance}
```

**Expected output format:** A performance scorecard with: (1) Overall rating (Excellent / Good / Fair / Poor), (2) Ratings by category (RFI Quality, Submittal Compliance, Quality, Safety, Schedule), (3) Strengths, (4) Areas for improvement, (5) Recommended management strategy (e.g., increased inspections, weekly coordination meetings, formal cure notice, etc.).

**Pro tip:** Track submittal R&R (Revise & Resubmit) rate as a leading indicator — a sub whose R&R rate exceeds 30% will likely have above-average field quality issues later.

---

### Prompt 8.5 — Extract Action Items from Meeting Notes

**Extract all action items, decisions, and pending items from the following meeting notes. Organize them into a clear action register with assignments and deadlines:**

```text
Meeting Type: {meeting_type}
Date: {meeting_date}
Raw Meeting Notes:
{raw_notes}
```

**Expected output format:** A three-part output:
1. **Decisions Made** — brief list of all decisions with who made them
2. **Action Items** — table: #, Action Description, Assigned To, Due Date, Priority (High/Med/Low)
3. **Open/Pending Items** — items discussed but not resolved, with who is responsible for follow-up

**Pro tip:** During the meeting, assign every action item to a specific person by name — "the team" is not an assignee and will result in zero follow-through.

---

### Prompt 8.6 — Draft Project Status for Owner Reporting

**Draft a concise project status update suitable for submission to the owner or owner's representative. Focus on contractual milestones, progress against approved schedule, change order status, and issues requiring owner input:**

```text
Project: {project_name}
Project #: {project_number}
Reporting Period: {period_start} to {period_end}
Owner: {owner_name}
Contract Value: ${contract_value}
Approved COs to Date: ${approved_co_value}
Pending COs: ${pending_co_value}
Original Completion: {original_completion}
Approved Extended Completion: {approved_extended_completion}
Forecast Completion: {forecast_completion}
% Complete: {percent_complete}
Schedule Status: {schedule_status}
Safety Record (current period): {safety_record_period}
Safety Record (project to date): {safety_record_to_date}
Work Completed This Period: {work_completed}
Work Planned Next Period: {work_planned}
Issues Requiring Owner Decision: {owner_decision_items}
Submittal Status: {submittal_status_summary}
RFI Status: {rfi_status_summary}
Photographs Attached: {photo_list}
```

**Expected output format:** A formal owner status report with: (1) Reporting header, (2) Schedule and cost status summary (table format), (3) Narrative: work completed this period, (4) Narrative: work planned next period, (5) Change order log summary, (6) Owner action items (decisions needed), (7) RFI/submittal summary, (8) Safety and quality highlights, (9) Attachments list.

**Pro tip:** Separate owner decisions needed from contractor decisions needed — if you mix them together, the owner's team will only act on the ones they want to and claim they missed the rest.

---

## Quick Reference — Prompt Count by Category

| # | Category | Count |
|---|----------|-------|
| 1 | RFI Management | 8 |
| 2 | Submittal Review | 6 |
| 3 | Spec Analysis | 5 |
| 4 | Schedule & Planning | 6 |
| 5 | Estimating & Bidding | 6 |
| 6 | Correspondence | 5 |
| 7 | Safety & Quality | 5 |
| 8 | General Productivity | 6 |
| | **Total** | **47** |

---

*Created for construction PMs, superintendents, and engineers. Designed for copy-paste use with any LLM platform.*